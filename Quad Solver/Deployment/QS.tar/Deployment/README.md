Packages the program.
=====================

- To deploy program:
make deploy


- To run all tests:
make test


- To run only unit tests:
make unit-test


- To run only integration tests:
make integration-test
