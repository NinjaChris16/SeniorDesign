int calc_roots(Coef, int, Root *);
