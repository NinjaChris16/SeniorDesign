void setup_mock_sqrt(double lx, double lsqrtx, double leps);
int check_mock_sqrt(int *lcount, double *lx);
void teardown_mock_sqrt();
