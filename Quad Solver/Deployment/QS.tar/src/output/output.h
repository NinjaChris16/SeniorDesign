int output(char *);
