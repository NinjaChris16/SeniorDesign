int num_roots(Coef);
