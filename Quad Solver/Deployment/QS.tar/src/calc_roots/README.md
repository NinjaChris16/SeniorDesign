calc_roots
==========

Quad-solver
