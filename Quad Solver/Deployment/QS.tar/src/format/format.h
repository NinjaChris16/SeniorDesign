char *format(int, Root);
