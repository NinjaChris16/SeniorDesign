int input_val(Coef * coef, char *input);
