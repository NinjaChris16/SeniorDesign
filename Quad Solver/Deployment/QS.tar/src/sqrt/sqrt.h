double qsolve_sqrt(double);
